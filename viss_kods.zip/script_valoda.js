document.addEventListener('DOMContentLoaded', function() {
    const lvButton = document.querySelector('.language-button[onclick="changeLanguage(\'lv\')"]');
    const enButton = document.querySelector('.language-button[onclick="changeLanguage(\'en\')"]');
    const translations = {
        'Sveiks! Esmu Dāvis': 'Hello! I\'m Dāvis',
        'Sociālais darbinieks un topošais programmētājs': 'Social worker and aspiring programmer',
        'Skatīt darbus': 'View projects',
        'Programmēšana': 'Programming',
        'Apgūstu programmēšanas tehniķa programmu, fokusējoties uz web izstrādi.': 'Studying the programming technician program, focusing on web development.',
        'Excel Projekti': 'Excel Projects',
        'Izveidojis vairākas platformas sociālās aprūpes datu pārvaldībai.': 'Created several platforms for managing social care data.',
        'Sociālais Darbs': 'Social Work',
        '13+ gadu pieredze sociālajā jomā, strādājot dažādos sektoros.': '13+ years of experience in the social field, working in various sectors.',
        'Sākums': 'Home',
        'Par mani': 'About me',
        'Programmēšana': 'Programming',
        'Excel': 'Excel',
        'Prasmes': 'Skills',
        'Atsauksmes': 'Testimonials',
        'Kontakti': 'Contact'
        // Šeit pievienojiet citus jūsu mājaslapas tekstus un to tulkojumus
    };

    function translateToEnglish() {
        document.documentElement.lang = 'en'; // Mainām <html> valodas atribūtu

        // Pārbaudām, vai elements pastāv pirms mēģināt tam piekļūt
        const typewriterHeading = document.querySelector('.typewriter');
        if (typewriterHeading) {
            typewriterHeading.textContent = translations['Sveiks! Esmu Dāvis'] || 'Hello! I\'m Dāvis';
        }

        const heroParagraph = document.querySelector('.hero-content p');
        if (heroParagraph) {
            heroParagraph.textContent = translations['Sociālais darbinieks un topošais programmētājs'] || 'Social worker and aspiring programmer';
        }

        const viewProjectsLink = document.querySelector('.hero-content a.btn');
        if (viewProjectsLink) {
            viewProjectsLink.textContent = translations['Skatīt darbus'] || 'View projects';
        }

        const card1Heading = document.querySelector('.card:nth-child(1) h2');
        if (card1Heading) {
            card1Heading.textContent = translations['Programmēšana'] || 'Programming';
        }

        const card1Paragraph = document.querySelector('.card:nth-child(1) p');
        if (card1Paragraph) {
            card1Paragraph.textContent = translations['Apgūstu programmēšanas tehniķa programmu, fokusējoties uz web izstrādi.'] || 'Studying the programming technician program, focusing on web development.';
        }

        const card2Heading = document.querySelector('.card:nth-child(2) h2');
        if (card2Heading) {
            card2Heading.textContent = translations['Excel Projekti'] || 'Excel Projects';
        }

        const card2Paragraph = document.querySelector('.card:nth-child(2) p');
        if (card2Paragraph) {
            card2Paragraph.textContent = translations['Izveidojis vairākas platformas sociālās aprūpes datu pārvaldībai.'] || 'Created several platforms for managing social care data.';
        }

        const card3Heading = document.querySelector('.card:nth-child(3) h2');
        if (card3Heading) {
            card3Heading.textContent = translations['Sociālais Darbs'] || 'Social Work';
        }

        const card3Paragraph = document.querySelector('.card:nth-child(3) p');
        if (card3Paragraph) {
            card3Paragraph.textContent = translations['13+ gadu pieredze sociālajā jomā, strādājot dažādos sektoros.'] || '13+ years of experience in the social field, working in various sectors.';
        }

        // Tulkojam navigācijas elementus (pieņemot, ka header.html ir ielādēts)
        const navLinks = document.querySelectorAll('#header .navbar-menu a');
        if (navLinks.length >= 7) {
            navLinks[0].textContent = translations['Sākums'] || 'Home';
            navLinks[1].textContent = translations['Par mani'] || 'About me';
            navLinks[2].textContent = translations['Programmēšana'] || 'Programming';
            navLinks[3].textContent = translations['Excel'] || 'Excel';
            navLinks[4].textContent = translations['Prasmes'] || 'Skills';
            navLinks[5].textContent = translations['Atsauksmes'] || 'Testimonials';
            navLinks[6].textContent = translations['Kontakti'] || 'Contact';
        }

        // Aktivizējam EN pogu un deaktivizējam LV pogu
        if (enButton && lvButton) {
            enButton.classList.add('active');
            lvButton.classList.remove('active');
        }
    }

    function translateToLatvian() {
        document.documentElement.lang = 'lv'; // Mainām <html> valodas atribūtu

        // Atjaunojam tekstu latviešu valodā
        const typewriterHeading = document.querySelector('.typewriter');
        if (typewriterHeading) {
            typewriterHeading.textContent = 'Sveiks! Esmu Dāvis';
        }

        const heroParagraph = document.querySelector('.hero-content p');
        if (heroParagraph) {
            heroParagraph.textContent = 'Sociālais darbinieks un topošais programmētājs';
        }

        const viewProjectsLink = document.querySelector('.hero-content a.btn');
        if (viewProjectsLink) {
            viewProjectsLink.textContent = 'Skatīt darbus';
        }

        const card1Heading = document.querySelector('.card:nth-child(1) h2');
        if (card1Heading) {
            card1Heading.textContent = 'Programmēšana';
        }

        const card1Paragraph = document.querySelector('.card:nth-child(1) p');
        if (card1Paragraph) {
            card1Paragraph.textContent = 'Apgūstu programmēšanas tehniķa programmu, fokusējoties uz web izstrādi.';
        }

        const card2Heading = document.querySelector('.card:nth-child(2) h2');
        if (card2Heading) {
            card2Heading.textContent = 'Excel Projekti';
        }

        const card2Paragraph = document.querySelector('.card:nth-child(2) p');
        if (card2Paragraph) {
            card2Paragraph.textContent = 'Izveidojis vairākas platformas sociālās aprūpes datu pārvaldībai.';
        }

        const card3Heading = document.querySelector('.card:nth-child(3) h2');
        if (card3Heading) {
            card3Heading.textContent = 'Sociālais Darbs';
        }

        const card3Paragraph = document.querySelector('.card:nth-child(3) p');
        if (card3Paragraph) {
            card3Paragraph.textContent = '13+ gadu pieredze sociālajā jomā, strādājot dažādos sektoros.';
        }

        // Atjaunojam navigācijas elementus latviešu valodā
        const navLinks = document.querySelectorAll('#header .navbar-menu a');
        if (navLinks.length >= 7) {
            navLinks[0].textContent = 'Sākums';
            navLinks[1].textContent = 'Par mani';
            navLinks[2].textContent = 'Programmēšana';
            navLinks[3].textContent = 'Excel';
            navLinks[4].textContent = 'Prasmes';
            navLinks[5].textContent = 'Atsauksmes';
            navLinks[6].textContent = 'Kontakti';
        }

        // Aktivizējam LV pogu un deaktivizējam EN pogu
        if (enButton && lvButton) {
            lvButton.classList.add('active');
            enButton.classList.remove('active');
        }
    }

    // Pievienojam notikumu klausītājus valodu pogām
    if (enButton) {
        enButton.addEventListener('click', translateToEnglish);
    }

    if (lvButton) {
        lvButton.addEventListener('click', translateToLatvian);
    }

    // Pēc lapas ielādes pārbaudām, kura valoda varētu būt iestatīta (piemēram, no localStorage) un attiecīgi aktivizējam pogu.
    // Šo daļu varat pielāgot atkarībā no tā, kā jūs glabājat lietotāja valodas izvēli.
    if (document.documentElement.lang === 'en') {
        if (enButton && lvButton) {
            enButton.classList.add('active');
            lvButton.classList.remove('active');
        }
    } else {
        if (enButton && lvButton) {
            lvButton.classList.add('active');
            enButton.classList.remove('active');
        }
    }
});